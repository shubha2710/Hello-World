package com.db;


	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.SQLException;



	public class DatabaseConfig{
		 
	    
	    static Connection con;
		static String connectionUrl = "jdbc:sqlserver://172.23.132.13:1433;databaseName=STAYHEALTHY;user=sa;password=password@123";
		
		public static Connection getDBConnection() {
		        Connection dbConnection = null;
		        try {
		            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		            System.out.println("load driver");
		           
		        } catch (ClassNotFoundException e) {
		            System.out.println("hii:"+e.getMessage());
		        }
		        try {
		            dbConnection = DriverManager.getConnection(connectionUrl);
		            System.out.println("return conn obj");
		            return dbConnection;
		        } catch (SQLException e) {
		            System.out.println("hlo:"+e.getMessage());
		        }
		        return dbConnection;
		    }


	}

