package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.Userdao;
import com.dao.Userdaoimpl;
import com.model.Employee;
import com.model.Patient;

/**
 * Servlet implementation class RegistrationServlet
 */
@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String employeeid=request.getParameter("employeeid"); 
	    System.out.println("eid:"+employeeid);
	    Userdao userDao=new Userdaoimpl();
		
	if(employeeid==null)
		{
				Patient patient=new Patient();
		
	    
				patient.setFullname(request.getParameter("username"));
				patient.setEmailid(request.getParameter("emailid"));
				patient.setAddress(request.getParameter("address"));
				patient.setPhone(request.getParameter("phone"));
				patient.setPassword(request.getParameter("password"));
				
				userDao.savePatient(patient);
				
				
				RequestDispatcher rd=request.getRequestDispatcher("/login.jsp");
				rd.forward(request,response );
				
						
		}
		
	else if(employeeid.contains("EMP"))		
		{
			Employee employee=new Employee();
			System.out.print("Hello");
			employee.setEmployeeid(employeeid);
			employee.setFullname(request.getParameter("username"));
			employee.setEmailid(request.getParameter("emailid"));
			employee.setAddress(request.getParameter("address"));
			employee.setPhone(request.getParameter("phone"));
			employee.setPassword(request.getParameter("password"));
			employee.setRole(request.getParameter("role"));

			userDao.saveEmployee(employee);
			RequestDispatcher rd=request.getRequestDispatcher("/login.jsp");
			rd.forward(request,response );
			
		}
		else
		{
			
		}
		
		
		
		
	}
}
