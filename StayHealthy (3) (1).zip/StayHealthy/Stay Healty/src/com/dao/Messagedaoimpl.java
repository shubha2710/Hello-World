package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.db.DatabaseConfig;
import com.model.Inbox;
import com.model.Outbox;

public class Messagedaoimpl implements MessageDao {
	
	DatabaseConfig config=new DatabaseConfig();
	Connection con;
	PreparedStatement stmt ;
	public List<Inbox> getInboxMessage(String emailId){
		List<Inbox> listInbox=new ArrayList();
		try {
		con=DatabaseConfig.getDBConnection();
		
	System.out.println("tomail"+emailId);
			stmt=con.prepareStatement("select * from Inbox where ToEmail=?");
			stmt.setString(1, emailId);
			  ResultSet rs=stmt.executeQuery();  
			  while(rs.next())
			  {
				  Inbox inbox=new Inbox();
				  
				  /*ystem.out.println(rs.getInt("MessageID"));
				  System.out.println(rs.getString("FromEmail"));
				  System.out.println(rs.getString("Subject"));
				  System.out.println(rs.getString("Content"));
				  System.out.println(rs.getDate("Datetime"));*/
				  
				  
				inbox.setMessageId(rs.getInt("MessageID"));
				inbox.setFrom(rs.getString("FromEmail"));
				inbox.setSubject(rs.getString("Subject"));
				inbox.setContent(rs.getString("Content"));
				inbox.setDatetime(rs.getDate("Datetime"));
			
				  listInbox.add(inbox);
			  }
	
		
		} 
		catch (SQLException e) {
			
			System.out.println(e);
		}
		return listInbox;
		
	
		
	}
	public boolean getOutboxMessage(Outbox outbox) {
		try {
		con=DatabaseConfig.getDBConnection();
		System.out.println("inserting records into the table ");
	
			stmt=con.prepareStatement("select * from Outbox");
			stmt.setString(1, outbox.getFrom());
			stmt.setString(2, outbox.getTo());
			stmt.setString(3, outbox.getContent());
			  ResultSet rs=stmt.executeQuery();  
		        boolean status = rs.next();  
	System.out.println("Inbox validate"+status);
		return status;
		} 
		catch (SQLException e) {
			
			System.out.println(e);
		}
		return false;
		
	}
	
	private static java.sql.Date getCurrentDate() {
	    java.util.Date today = new java.util.Date();
	    return new java.sql.Date(today.getTime());
	}
	
	@Override
	public boolean composedMessage(Outbox outbox) {
		
		Inbox inbox=new Inbox();
		System.out.println(outbox.getFrom());
		inbox.setTo(outbox.getTo());
		inbox.setFrom(outbox.getFrom());
		inbox.setContent(outbox.getContent());
		inbox.setSubject(outbox.getSubject());
		//inbox.setDatetime(new Date());
		//outbox.setDatetime(new Date());
		try {
			con=DatabaseConfig.getDBConnection();
			System.out.println("inside msg dao impl ");
		
				stmt=con.prepareStatement("insert into Outbox(FromEmail,ToEmail,Subject,Content,Datetime) values(?, ?, ?,?,?)");
		
				stmt.setString(1, outbox.getFrom());
		
				stmt.setString(2, outbox.getTo());
			
				stmt.setString(3, outbox.getSubject());
		
				stmt.setString(4, outbox.getContent());
				System.out.println("err-5");
				
				stmt.setDate(5, getCurrentDate());
				System.out.println("err-6");
				int i=stmt.executeUpdate();
				System.out.println("err-7");
				
				System.out.println(i+ "records inserted");
				
			   stmt.close();
			   con.close();
			} 
			catch (SQLException e) {
				  
				System.out.println(e);
				return false;
			}
		try {con=DatabaseConfig.getDBConnection();
		System.out.println("inserting records into the table ");
		
		stmt=con.prepareStatement("insert into Inbox(FromEmail,ToEmail,Subject,Content,Datetime) values( ?,?, ?,?,?)");
		stmt.setString(1, outbox.getFrom());
		stmt.setString(2, outbox.getTo());
		stmt.setString(3, outbox.getSubject());
		stmt.setString(4, outbox.getContent());
		stmt.setDate(5, getCurrentDate());
		int i=stmt.executeUpdate();
		
		System.out.println(i+ "records inserted");
		
	   stmt.close();
	   con.close();
			
	 
		}
		catch(SQLException e) {
			return false;
		}
		  return true;
		
	}
	@Override
	public List<Outbox> getOutboxMessage(String emailId) {
		List<Outbox> listOutbox=new ArrayList();
		try {
		con=DatabaseConfig.getDBConnection();
		System.out.println("inserting records into the table ");
	
			stmt=con.prepareStatement("select * from Outbox where FromEmail=?");
			stmt.setString(1, emailId);
			  ResultSet rs=stmt.executeQuery();  
			  while(rs.next())
			  {
				  Outbox outbox=new Outbox();
				  outbox.setMessageId(rs.getInt("MessageID"));
				  outbox.setTo(rs.getString("ToEmail"));
				  outbox.setSubject(rs.getString("Subject"));
				  outbox.setContent(rs.getString("Content"));
				  outbox.setDatetime(rs.getDate("Datetime"));
				
				  
				  listOutbox.add(outbox);
			  }
	
		
		} 
		catch (SQLException e) {
			
			System.out.println(e);
		}
		return listOutbox;
		
	
	}
	@Override
	public Inbox getMessage(int messageId) {
		 Inbox inbox=new Inbox();
		try {
			con=DatabaseConfig.getDBConnection();
			
			
				stmt=con.prepareStatement("select * from Inbox where MessageID=?");
				stmt.setInt(1, messageId);
				  ResultSet rs=stmt.executeQuery();  
				  while(rs.next())
				  {
					
					 
					 inbox.setContent(rs.getString("Content"));
					 inbox.setFrom(rs.getString("FromEmail"));
					 inbox.setTo(rs.getString("ToEmail"));
					 inbox.setDatetime(rs.getDate("Datetime"));
					 inbox.setSubject(rs.getString("Subject"));
					  
					  
				  }
		
			
			} 
			catch (SQLException e) {
				
				System.out.println(e);
			}
			return inbox;
	}


}
