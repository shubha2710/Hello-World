package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.tomcat.dbcp.dbcp2.ConnectionFactory;

import com.db.DatabaseConfig;
import com.model.Employee;
import com.model.Patient;

public class Userdaoimpl implements Userdao {

	
	DatabaseConfig config=new DatabaseConfig();
	Connection con;
	PreparedStatement stmt ;
	public boolean savePatient(Patient patient) {
		
		try {
		con=DatabaseConfig.getDBConnection();
		System.out.println("inserting records into the table ");
		stmt=con.prepareStatement("insert into PATIENT(fullname,address,emailaddress,password,phonenumber) values(?, ?, ?,?,?)");
	
		
		stmt.setString(1, patient.getFullname());
		stmt.setString(2, patient.getAddress());
		stmt.setString(3, patient.getEmailid());
		stmt.setString(4, patient.getPassword());
		stmt.setString(5, patient.getPhone());
		int i=stmt.executeUpdate();
		
		System.out.println(i+ "records inserted");
		
	   stmt.close();
	   con.close();
		return false;
		}
		catch(SQLException e) {
			System.out.println(e);
		}
		return false;
	}


public boolean saveEmployee(Employee employee) {
	
	
		
		try {
			con=DatabaseConfig.getDBConnection();
			System.out.println("inserting records into the table ");
			stmt=con.prepareStatement("insert into EMPLOYEE(id,fullname,address,emailaddress,password,phonenumber,role) values(?,?, ?, ?,?,?,?)");

			stmt.setString(1, employee.getEmployeeid());
			stmt.setString(2, employee.getFullname());
			stmt.setString(3, employee.getAddress());
			stmt.setString(4, employee.getEmailid());
			stmt.setString(5, employee.getPassword());
			stmt.setString(6, employee.getPhone());
			stmt.setString(7, employee.getRole());
			int i=stmt.executeUpdate();
			
			System.out.println(i+ "records inserted");
			
		   stmt.close();
		   con.close();
			return false;
			}
			catch(SQLException e) {
				System.out.println(e);
			}
		return false;
			
		}



@Override
public boolean validatePatient(Patient patient) {
	// TODO Auto-generated method stub
	
	try {
	con=DatabaseConfig.getDBConnection();
	stmt=con.prepareStatement("select * from Patient where EmailAddress =? and Password=?");
			stmt.setString(1, patient.getEmailid());
	        stmt.setString(2, patient.getPassword());
	        ResultSet rs=stmt.executeQuery();  
	        boolean status = rs.next();  
System.out.println("patient validate"+status);
	return status;
	}
	catch(SQLException e) {
		System.out.println(e);
	}
return false;
	
}


@Override
public boolean validateEmployee(Employee employee) {
	

	try {
	con=DatabaseConfig.getDBConnection();
	stmt=con.prepareStatement("select * from employee where id =? and Password=?");
			stmt.setString(1, employee.getEmployeeid());
	        stmt.setString(2, employee.getPassword());
	        ResultSet rs=stmt.executeQuery();  
	        boolean status = rs.next();  
	        System.out.println("valid user"+status);
	return status;
	}
	catch(SQLException e) {
		System.out.println(e);
	}
	return false;
}


@Override
public Employee getEmployee(String empid) {
	try {
		con=DatabaseConfig.getDBConnection();
		stmt=con.prepareStatement("select * from EMPLOYEE where id=?");
		stmt.setString(1,empid );
		ResultSet rs=stmt.executeQuery(); 
		rs.next();
		Employee e=new Employee();
		e.setEmailid(rs.getString("EmailAddress"));
		e.setAddress(rs.getString("Address"));
		e.setFullname(rs.getString("FullName"));
		e.setPhone(rs.getString("PhoneNumber"));
		
		return e;
        
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	// TODO Auto-generated method stub
	return null;
}

}

		
	





