package com.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.MessageDao;
import com.dao.Messagedaoimpl;
import com.dao.Userdao;
import com.dao.Userdaoimpl;
import com.model.Inbox;
import com.model.Outbox;

/**
 * Servlet implementation class MessageController
 */
@WebServlet("/MessageController")
public class MessageController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MessageController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   
	   doGet( request,  response);
   }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		System.out.println("action"+action);
		 Userdao userDao=new Userdaoimpl();
		 
		 
		
			 
		 
		try {
			
			switch(action)
			{
			case "outbox":getOutbox(request,response);break;
			case "compose": composeMail(request,response);break;
			case "showMessage": showMessage(request,response);break;
			case "sendMessage": sendMessage(request,response);break;
			default:
				getInbox(request,response);
			
			}
		}
		catch(Exception e)
		{
			
		}
	}

	private void sendMessage(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session=request.getSession(true);
		String fromemail=(String)session.getAttribute("currentUser");
		String toemail=request.getParameter("toemail");
		
	}

	private void showMessage(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession(true);
		String emailId=(String)session.getAttribute("currentUser");
		int msgId=Integer.parseInt(request.getParameter("msgid"));
		
		
		MessageDao messageDao=new Messagedaoimpl();
		
		Inbox inbox=messageDao.getMessage(msgId);
		
		
		RequestDispatcher rd=request.getRequestDispatcher("inbox.jsp");
		request.setAttribute("inboxMessage",inbox);
			
			rd.forward(request, response);
		
	}

	private void getOutbox(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("in side getoutbox");
		HttpSession session=request.getSession(true);
		String emailId=(String)session.getAttribute("currentUser");
		System.out.println("email"+emailId);
		
		MessageDao messageDao=new Messagedaoimpl();
		
		List<Outbox> listMessage=messageDao.getOutboxMessage(emailId);
		
		for(Outbox i:listMessage)
		{
			
			System.out.println("user content:"+i.getSubject());
			
		}
		
			RequestDispatcher rd=request.getRequestDispatcher("Messagebox.jsp");
		request.setAttribute("listMessage",listMessage);
			rd.forward(request, response);
		
	}

	private void composeMail(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Outbox outbox= new Outbox();
		 
		HttpSession session=request.getSession(true);
		String fromeEmail=(String)session.getAttribute("currentUser");
		
		outbox.setFrom(fromeEmail);
		System.out.println("frommail:"+outbox.getFrom());
		outbox.setTo(request.getParameter("toemail"));
		outbox.setContent(request.getParameter("content"));
		outbox.setSubject(request.getParameter("subject"));
		MessageDao messageDao=new Messagedaoimpl();
	if(	messageDao.composedMessage(outbox))
	{
		
		List<Inbox> listMessage=messageDao.getInboxMessage(fromeEmail);
		
		RequestDispatcher rd=request.getRequestDispatcher("Messagebox.jsp");
		request.setAttribute("listMessage",listMessage);
			rd.forward(request, response);
	}
		
	}

	private void getInbox(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("in side getinbox");
	HttpSession session=request.getSession(true);
	String emailId=(String)session.getAttribute("currentUser");
	
	
	MessageDao messageDao=new Messagedaoimpl();
	
	List<Inbox> listMessage=messageDao.getInboxMessage(emailId);
	
	for(Inbox i:listMessage)
	{
		System.out.println("user content:"+i.getSubject());
	}
	
		RequestDispatcher rd=request.getRequestDispatcher("Messagebox.jsp");
	request.setAttribute("listMessage",listMessage);
		rd.forward(request, response);
		
	}

	
}