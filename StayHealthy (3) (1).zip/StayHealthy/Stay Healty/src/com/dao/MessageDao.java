package com.dao;

import java.util.List;

import com.model.Inbox;
import com.model.Outbox;

public interface MessageDao {

	public boolean composedMessage(Outbox outbox);
	public List<Inbox> getInboxMessage(String emailId);
	public List<Outbox> getOutboxMessage(String emailId);
	
	public Inbox getMessage(int messageId);
	
	
}
