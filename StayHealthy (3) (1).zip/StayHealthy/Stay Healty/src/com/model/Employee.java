package com.model;

public class Employee {
	String Employeeid;
	String FullName;
	String emailid;
	String password;
	String address;
	String phone;
	String role;
	
	
	public String getFullname() {
		return FullName;
	}
	public void setFullname(String fullname) {
		FullName = fullname;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getEmployeeid() {
		return Employeeid;
	}
	public void setEmployeeid(String employeeid) {
		Employeeid = employeeid;
	}
	
}
