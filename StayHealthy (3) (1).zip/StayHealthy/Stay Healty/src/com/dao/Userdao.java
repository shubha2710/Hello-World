package com.dao;

import com.model.Employee;
import com.model.Patient;

public interface Userdao {
	public boolean savePatient(Patient patient);
	public boolean saveEmployee(Employee employee);
	public  boolean validatePatient(Patient patient);
	public  boolean validateEmployee(Employee employee) ;
    
	public Employee getEmployee(String empid);
    
	
	}
